"""Wine quality MLOps package."""

__version__ = "0.1.0"
